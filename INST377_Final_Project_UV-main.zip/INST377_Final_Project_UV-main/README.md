# INST377_Final_Project_UV
Final Project for INST377
Project TItle: UV Index by Location

Group Members: Kyle McConeghy and Jeffrey Gomes

This is our original repository we accidentally started and did most of our work on
A link to our official repository can be found below

https://github.com/INST377-UMD/inst377-group-project-kylemcconeghy.git


Project Description: 
Many people downplay the harmful effects of the sun. In addition, many people forget that the easiest way to protect yourself against the sun is to put on some sunscreen or even some lotion with SPF in it. Our application aims to help protect you against many of the harmful affects that the sun can have on our skin from sunburn to skin cancer. What we hope to accomplish it to spread awareness, as well as spark peoples attention to taking care of themselves and their skin for the future.

Target Browsers: 
We want to Target users on iOS and Android devices to reach as many people as possible

User Manual:

[a relative link] (docs/user_manual.md)

Developer Manual:

[a relative link] (docs/dev_manual.md)

